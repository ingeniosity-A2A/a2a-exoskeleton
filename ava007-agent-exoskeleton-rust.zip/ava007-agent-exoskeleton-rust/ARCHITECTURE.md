# AVA007 Agent Exoskeleton — Rust Execution Core

This crate is the Rust execution boundary for the AVA007 Agent Browser / Cybernetic
Exoskeleton console.

## Placement

```text
AVA007
└── Intellect
    └── Inferential Kernel        <-- this crate's kernel boundary
            │
            └── Cybernetic Bus
                    │
                    ▼
                Exoskeleton
                    ├── agent-browser
                    ├── Bash
                    ├── Linux
                    ├── Termux
                    ├── Document Ingestion
                    └── CodeBluff
```

The kernel proposes capabilities. The Exoskeleton/Freebuff execution layer
authorizes and executes them.

## Figure-8

```text
        INTELLECT
            │
      Inferential Kernel
            │
         decision
            │
            ▼
       EXOSKELETON
            │
        observation
            │
            └──────────► INTELLECT
```

## Existing-system integration

Do not duplicate existing AVA007 browser, ingestion, MemBrain, GSAP, or terminal
implementations. Wire those systems through the adapter traits.

The Rust process exposes:

- `GET /healthz`
- `POST /v1/kernel/infer`

## Freebuff role

Freebuff should execute the Rust target:

```bash
cargo check
cargo run --release
```

and, once the repository adapter is wired, execute the approved capability
proposals emitted by the kernel.

The kernel deliberately does not execute arbitrary shell commands itself.
That keeps Intellect separate from Exoskeleton actuation and preserves the
cybernetic control boundary.
