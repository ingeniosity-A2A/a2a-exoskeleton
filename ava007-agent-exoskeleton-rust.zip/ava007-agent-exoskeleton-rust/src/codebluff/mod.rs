use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CodeIntelligenceRequest {
    pub task: String,
    pub repository: Option<String>,
    pub benchmark: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CodeIntelligenceResult {
    pub curator: &'static str,
    pub sources: Vec<&'static str>,
    pub status: &'static str,
}

pub fn curate(_request: CodeIntelligenceRequest) -> CodeIntelligenceResult {
    CodeIntelligenceResult {
        curator: "CodeBluff",
        sources: vec!["Freebuff", "Repomix", "Codex CLI"],
        status: "ready-for-execution",
    }
}
