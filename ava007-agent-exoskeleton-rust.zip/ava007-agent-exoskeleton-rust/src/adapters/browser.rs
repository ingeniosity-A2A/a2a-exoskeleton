use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BrowserObservation {
    pub url: String,
    pub title: Option<String>,
    pub snapshot: Option<String>,
    pub downloaded_artifacts: Vec<String>,
}

// Adapter target for agent-browser.
// Keep agent-browser as the browser substrate; do not reimplement Chrome/CDP here.
pub trait AgentBrowserAdapter: Send + Sync {
    fn snapshot(&self, url: &str) -> anyhow::Result<BrowserObservation>;
}
