use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IngestionArtifact {
    pub artifact_id: String,
    pub mime_type: String,
    pub source: String,
    pub path: Option<String>,
}

pub trait IngestionAdapter: Send + Sync {
    fn submit(&self, artifact: IngestionArtifact) -> anyhow::Result<()>;
}
