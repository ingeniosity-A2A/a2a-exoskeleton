use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub enum TerminalContext {
    Bash,
    Linux,
    Termux,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TerminalRequest {
    pub context: TerminalContext,
    pub command: String,
}

// Execution remains delegated to Freebuff/the existing Exoskeleton runtime.
// This boundary prevents the kernel from becoming an unrestricted shell.
pub trait TerminalAdapter: Send + Sync {
    fn dispatch(&self, request: TerminalRequest) -> anyhow::Result<()>;
}
