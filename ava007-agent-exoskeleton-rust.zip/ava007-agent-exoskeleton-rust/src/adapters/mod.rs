// Adapters are intentionally thin. Existing AVA007 services remain the source
// of truth; this crate provides stable Rust boundaries for wiring them into
// Intellect/Exoskeleton without duplicating their implementations.

pub mod browser;
pub mod ingestion;
pub mod terminals;
