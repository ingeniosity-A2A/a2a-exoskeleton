use serde::{Deserialize, Serialize};
use std::sync::RwLock;
use std::time::{SystemTime, UNIX_EPOCH};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Observation {
    pub source: String,
    pub kind: String,
    pub payload: serde_json::Value,
    pub timestamp_ms: u128,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ActionProposal {
    pub capability: String,
    pub authorized: bool,
}

impl ActionProposal {
    pub fn new(capability: &str) -> Self {
        Self {
            capability: capability.to_string(),
            // Authorization belongs to the Exoskeleton policy/capability layer.
            authorized: false,
        }
    }
}

pub struct CyberneticBus {
    latest: RwLock<Option<Observation>>,
}

impl CyberneticBus {
    pub fn new() -> Self {
        Self {
            latest: RwLock::new(None),
        }
    }

    pub fn observe(&self, source: &str, kind: &str, payload: serde_json::Value) {
        let ts = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis();

        if let Ok(mut slot) = self.latest.write() {
            *slot = Some(Observation {
                source: source.into(),
                kind: kind.into(),
                payload,
                timestamp_ms: ts,
            });
        }
    }

    pub fn latest(&self) -> Option<Observation> {
        self.latest.read().ok().and_then(|v| v.clone())
    }
}
