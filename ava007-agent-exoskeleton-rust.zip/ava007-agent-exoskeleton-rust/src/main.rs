mod adapters;
mod codebluff;
mod exoskeleton;
mod kernel;

use std::sync::Arc;
use axum::{routing::{get, post}, Json, Router};
use serde_json::json;
use tokio::sync::RwLock;
use tracing::info;

use kernel::{InferenceKernel, KernelRequest};
use exoskeleton::CyberneticBus;

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter("info")
        .init();

    let bus = Arc::new(RwLock::new(CyberneticBus::new()));
    let kernel = Arc::new(InferenceKernel::new(bus.clone()));

    let health = Router::new()
        .route("/healthz", get(|| async {
            Json(json!({"ok": true, "service": "ava007-agent-exoskeleton"}))
        }))
        .route("/v1/kernel/infer", post({
            let kernel = kernel.clone();
            move |Json(req): Json<KernelRequest>| {
                let kernel = kernel.clone();
                async move {
                    match kernel.infer(req).await {
                        Ok(result) => Json(json!(result)),
                        Err(e) => Json(json!({
                            "ok": false,
                            "error": e.to_string()
                        })),
                    }
                }
            }
        }));

    let addr = "127.0.0.1:8770";
    info!("AVA007 Agent Exoskeleton listening on http://{addr}");
    let listener = tokio::net::TcpListener::bind(addr).await?;
    axum::serve(listener, health).await?;
    Ok(())
}
