use std::sync::Arc;
use serde::{Deserialize, Serialize};
use tokio::sync::RwLock;
use uuid::Uuid;

use crate::exoskeleton::{ActionProposal, CyberneticBus, Observation};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CognitiveState {
    pub goals: Vec<String>,
    pub observations: Vec<Observation>,
    pub active_surface: Option<String>,
    pub confidence: f32,
}

impl Default for CognitiveState {
    fn default() -> Self {
        Self {
            goals: vec![],
            observations: vec![],
            active_surface: None,
            confidence: 0.0,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct KernelRequest {
    pub intent: String,
    #[serde(default)]
    pub state: CognitiveState,
    #[serde(default)]
    pub evidence: Vec<String>,
    pub model: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InferenceResult {
    pub ok: bool,
    pub request_id: Uuid,
    pub intent: String,
    pub conclusion: String,
    pub confidence: f32,
    pub action: Option<ActionProposal>,
    pub state: CognitiveState,
}

pub struct InferenceKernel {
    bus: Arc<RwLock<CyberneticBus>>,
}

impl InferenceKernel {
    pub fn new(bus: Arc<RwLock<CyberneticBus>>) -> Self {
        Self { bus }
    }

    pub async fn infer(&self, req: KernelRequest) -> anyhow::Result<InferenceResult> {
        let request_id = Uuid::new_v4();

        // The kernel is deliberately an inference/state-transition boundary.
        // Model execution can be attached through the adapter layer without
        // moving the kernel outside Intellect.
        let conclusion = format!(
            "Intent accepted by Inferential Kernel: {}",
            req.intent
        );

        let confidence = if req.evidence.is_empty() { 0.50 } else { 0.80 };

        let action = self.propose_capability(&req.intent);

        let mut state = req.state;
        state.confidence = confidence;
        state.active_surface = Some("agent-exoskeleton".into());

        if let Some(obs) = self.bus.read().await.latest() {
            state.observations.push(obs);
            state.observations.truncate(64);
        }

        Ok(InferenceResult {
            ok: true,
            request_id,
            intent: req.intent,
            conclusion,
            confidence,
            action,
            state,
        })
    }

    fn propose_capability(&self, intent: &str) -> Option<ActionProposal> {
        let i = intent.to_ascii_lowercase();

        if i.contains("browser") {
            return Some(ActionProposal::new("browser.snapshot"));
        }
        if i.contains("pdf") || i.contains("document") {
            return Some(ActionProposal::new("ingestion.document"));
        }
        if i.contains("benchmark") {
            return Some(ActionProposal::new("dev.benchmark"));
        }
        if i.contains("code") || i.contains("repository") {
            return Some(ActionProposal::new("codebluff.curate"));
        }
        if i.contains("termux") {
            return Some(ActionProposal::new("terminal.termux"));
        }
        if i.contains("linux") {
            return Some(ActionProposal::new("terminal.linux"));
        }
        if i.contains("bash") {
            return Some(ActionProposal::new("terminal.bash"));
        }

        None
    }
}
